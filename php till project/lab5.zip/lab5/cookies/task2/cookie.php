<?php
setcookie("name", $_GET['name'], time()+3600);
setcookie("surname", $_GET['surname'], time()+3600);
setcookie("age", $_GET['age'], time()+3600);
setcookie("country", $_GET['country'], time()+3600);
setcookie("gender", $_GET['gender'], time()+3600);
setcookie("credit", $_GET['credit'], time()+3600);