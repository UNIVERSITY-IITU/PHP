<?php
$data = array();
$data['Adidas'] = 150;
$data['Reebok'] = 90;
$data['Nike Total'] = 70;
$_SESSION['data']=$data;
?>