<?php

$data = array();

$data['ru']['site_title'] = "Приложение по отправке формы";
$data['en']['site_title'] = "Application for sending a form";

$data['ru']['country_label'] = "Страна";
$data['en']['country_label'] = "Country";

$data['ru']['name_label'] = "Наименование";
$data['en']['name_label'] = "Name";

$data['ru']['gender_label'] = "Пол";
$data['en']['gender_label'] = "Gender";

