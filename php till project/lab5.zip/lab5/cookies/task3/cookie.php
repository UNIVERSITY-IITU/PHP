<?php
setcookie('lang', $_POST['lang']);